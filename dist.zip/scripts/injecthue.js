/*
 Dmitry Sadakov (c) 2015
*/

/*globals chrome*/
/*exported externalBackground */

var externalBackground = chrome.extension.getBackgroundPage();